/* Daniel Rocha Stanzani */ 
/* Murilo Favero Martin  */

#include <stdio.h>
#include <math.h>
main()
{
	float A, B, C, D, X;
	printf("Para resolver a equa��o de segundo grau: ax� + bx + c = 0\n");
	printf("Digite o valor de 'a': ");
	scanf("%f", &A);
	printf("Digite o valor de 'b': ");
	scanf("%f", &B);
	printf("Digite o valor de 'c': ");
	scanf("%f", &C);
	D = (B*B) - 4*(A*C);
	if ( A == 0 ){
		if (B == 0 && C != 0)
			printf("N�o h� solu��o.\n");
		else{
			if (C == 0 )
				printf("Quaquer valor satisfaz X.\n");
			else
				printf("O valor de X = %f\n", -(C/B));
		}
	}
	else{
		if ( D >= 0 ){
			D = sqrt(D);
			printf("O valor de X1 = %f\n", (-B/(2*A)) + D/(2*A));
			printf("O valor de X2 = %f\n", (-B/(2*A)) - D/(2*A));
		}
		else{
			X = (-B/(2*A));
			if (A < 0){
				A = -A;
			}
			D = (sqrt(-D))/(2*A);
			printf("O valor de X1 = %f + %fi\n", X, D);
			printf("O valor de X2 = %f - %fi\n", X, D);
		}
	}
}

/* Daniel Rocha Stanzani */ 
/* Murilo Favero Martin  */
